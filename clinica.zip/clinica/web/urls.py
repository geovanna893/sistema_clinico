from django.urls import path
from django.views.generic import TemplateView
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('',TemplateView.as_view(template_name='pag_inicio.html'), name='home'),
    path('pacientes/', views.lista_de_clientes, name='lista_de_clientes'),
    path('medicos/', views.lista_de_medicos, name='lista_de_medicos'),
    path('agendar_consulta/', views.agendar_consulta, name='agendar_consulta'),
    path('consultas/', views.lista_de_consultas, name='lista_de_consultas'),
    path('add_paciente/', views.add_paciente, name='add_paciente'),
    path('consulta_eventos_medicos', views.consulta_eventos_medicos, name='eventos_medicos'),
    path('eventos/', views.consulta_eventos, name='consulta_eventos'),
    path('pacientes/excluir/<int:pk>/', views.excluir_cliente, name='excluir_cliente'),
    path('medicos/excluir/<int:pk>/', views.excluir_medico, name='excluir_medico'),
    path('add_medico/', views.add_medico, name='add_medico'),
    path('consultas/excluir/<int:pk>/', views.excluir_consulta, name='excluir_consulta'),
    path('consultas/status/<int:pk>/', views.alterar_status_consulta, name='alterar_status_consulta'),
]