from django.db import models
from django.core.exceptions import ValidationError
import re
from datetime import date

def validar_cpf_formato(cpf):
    if not re.match(r'^\d{3}\.\d{3}\.\d{3}-\d{2}$', cpf):
        raise ValidationError('CPF deve estar no formato 000.000.000-00')

def validar_nome(nome):
    if not re.match(r'^[A-ZÁÉÍÓÚÂÊÎÔÛÃÕÇ][a-záéíóúâêîôûãõç]+(?: [A-ZÁÉÍÓÚÂÊÎÔÛÃÕÇ][a-záéíóúâêîôûãõç]+)+$', nome):
        raise ValidationError('Nome deve ter nome e sobrenome, começar com maiúscula. Ex: Maria Souza')

def validar_telefone(telefone):
    if not re.match(r'^\(\d{2}\) \d{4,5}-\d{4}$', telefone):
        raise ValidationError('Telefone deve estar no formato (00) 00000-0000')

def validar_crm(crm):
    if not re.match(r'^CRM/[A-Z]{2} \d{4,6}$', crm):
        raise ValidationError('CRM deve estar no formato CRM/UF 000000. Ex: CRM/SP 123456')

def validar_horario_atendimento(horario):
    if not re.match(r'^\d{2}:\d{2} - \d{2}:\d{2}$', horario):
        raise ValidationError('Horário deve estar no formato HH:MM - HH:MM. Ex: 09:00 - 18:00')


class Cliente(models.Model):
    paciente = models.CharField(max_length=60, null=False, blank=False, validators=[validar_nome])
    cpf = models.CharField(max_length=15, unique=True, null=False, blank=False, validators=[validar_cpf_formato])
    data_nascimento = models.DateField()
    telefone = models.CharField(max_length=15, validators=[validar_telefone])

    def clean(self):
        if self.data_nascimento:
            idade = (date.today() - self.data_nascimento).days // 365
            if idade < 6:
                raise ValidationError({'data_nascimento': 'Paciente deve ter no mínimo 6 anos.'})

    def __str__(self):
        return self.paciente


class Medico(models.Model):
    medico = models.CharField(max_length=60, null=False, blank=False, validators=[validar_nome])
    crm = models.CharField(max_length=20, unique=True, validators=[validar_crm])
    Especialidade = [
        ('C', 'Cardiologia'),
        ('O', 'Ortopedia'),
        ('P', 'Pediatria'),
        ('G', 'Ginecologia'),
        ('CM', 'Clínica Médica'),
    ]
    especialidade = models.CharField(max_length=2, choices=Especialidade, null=False, blank=False)
    horario_atendimento = models.CharField(max_length=15, validators=[validar_horario_atendimento])

    def __str__(self):
        return self.medico


class AgendamentoConsulta(models.Model):
    paciente = models.ForeignKey(Cliente, on_delete=models.CASCADE)
    medico = models.ForeignKey(Medico, on_delete=models.SET_NULL, null=True)
    data = models.DateTimeField()
    Status_consulta = [
        ('A', 'Agendada'),
        ('O', 'Ocorrendo'),
        ('R', 'Realizada'),
    ]
    status_consulta = models.CharField(max_length=1, choices=Status_consulta, default='A')
    justificativa_cancelamento = models.TextField(null=True, blank=True)
    data_cancelamento = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"Consulta de {self.paciente} com {self.medico} em {self.data}"