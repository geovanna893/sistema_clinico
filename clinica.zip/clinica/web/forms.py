from django import forms
from .models import AgendamentoConsulta, Cliente, Medico
import re
from datetime import date


class PacienteForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = '__all__'
        labels = {
            'paciente': 'Nome completo:',
            'cpf': 'CPF:',
            'data_nascimento': 'Data de nascimento:',
            'telefone': 'Telefone:',
        }
        widgets = {
            'data_nascimento': forms.DateInput(attrs={'type': 'date'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})

    def clean_data_nascimento(self):
        data = self.cleaned_data.get('data_nascimento')
        if data:
            idade = (date.today() - data).days // 365
            if idade < 6:
                raise forms.ValidationError('Paciente deve ter no mínimo 6 anos.')
        return data


class MedicoForm(forms.ModelForm):
    class Meta:
        model = Medico
        fields = '__all__'
        labels = {
            'medico': 'Nome completo:',
            'crm': 'CRM:',
            'especialidade': 'Especialidade:',
            'horario_atendimento': 'Horário de atendimento:',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})


class ConsultaForm(forms.ModelForm):
    class Meta:
        model = AgendamentoConsulta
        fields = ['paciente', 'medico', 'data']
        widgets = {
            'data': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})

    def clean_data(self):
        data = self.cleaned_data.get('data')
        if data:
            if data.weekday() > 4:
                raise forms.ValidationError('Consultas só podem ser agendadas de segunda a sexta.')
            hora = data.hour
            minuto = data.minute
            manha = (hora == 9 or (hora > 9 and hora < 12)) or (hora == 12 and minuto == 0)
            tarde = (hora == 14 or (hora > 14 and hora < 18)) or (hora == 18 and minuto == 0)
            if not (manha or tarde):
                raise forms.ValidationError('Horário deve ser entre 09:00-12:00 ou 14:00-18:00.')
        return data

    def clean(self):
        cleaned_data = super().clean()
        data = cleaned_data.get('data')
        medico = cleaned_data.get('medico')
        if data and medico:
            qs = AgendamentoConsulta.objects.filter(data=data, medico=medico)
            if self.instance.pk:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise forms.ValidationError(f'Já existe uma consulta com {medico} neste horário.')
        return cleaned_data