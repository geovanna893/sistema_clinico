import random
from django.shortcuts import render, get_list_or_404, get_object_or_404
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Cliente, AgendamentoConsulta, Medico
from .forms import ConsultaForm, PacienteForm, MedicoForm
from django.http import JsonResponse
from django.contrib.auth import login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required

def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            print(user)
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

@login_required(login_url='login')
def logout_view(request):
     logout(request)
     return redirect('login')

@login_required(login_url='login')
def lista_de_clientes(request):
    clientes = Cliente.objects.all()
    form_paciente = PacienteForm()
    return render(request, 'lista_de_clientes.html', {
        'clientes': clientes,
        'form_paciente': form_paciente
    })

@login_required(login_url='login')
def lista_de_medicos(request):
    medicos = Medico.objects.all()
    form_medico = MedicoForm()                  
    return render(request, 'lista_de_medicos.html', {
        'medicos': medicos,
        'form_medico': form_medico             
    })

@login_required(login_url='login')
def add_medico(request):
    if request.method == 'POST':
        form = MedicoForm(request.POST)
        if form.is_valid():
            medico = form.save()
            return JsonResponse({
                'id': medico.id,
                'medico': medico.medico,
                'crm': medico.crm,
            })
        else:
            return JsonResponse({'errors': form.errors}, status=400)
    else:
        form = MedicoForm()
    return render(request, 'add_medico_modal.html', {'form_medico': form})

@login_required(login_url='login')
def add_paciente(request):
     if request.method == 'POST':
          form = PacienteForm(request.POST)
          if form.is_valid():
               cliente = form.save()
               return JsonResponse(
                    {
                         'id': cliente.id,
                         'paciente': cliente.paciente,
                         'cpf': cliente.cpf
                    })
          else: 
               return JsonResponse({'errors': form.errors}, status=400)
     else:
          form = PacienteForm()
     return render(request, 'add_paciente_modal.html', {'form':form})


@login_required(login_url='login')
def agendar_consulta(request):
    form_paciente =  PacienteForm()
    cliente = None



    if "buscar" in request.POST:
         cpf =  request.POST.get("cpf")
         print(cpf)
         try:
              cliente = Cliente.objects.get(cpf=cpf)
              form = ConsultaForm(initial={'paciente': cliente})
              print(cliente)
         except Cliente.DoesNotExist:
              messages.error(request, 'Clliente não encontrado.')
              form = ConsultaForm

    elif "salvar" in request.POST:
         form = ConsultaForm(request.POST)
         if form.is_valid():
              form.save()
              messages.success(request, 'Consulta agendada com sucesso!')
              return redirect('lista_de_consultas')
         else:
              messages.error(request, 'Erro ao agendar consulta.')
    else:
         form = ConsultaForm()
         form_paciente = PacienteForm()

    
    return render(request, 'agendar_consulta.html', {'form': form, 'cliente': cliente, 'form_paciente': form_paciente})

@login_required(login_url='login')
def lista_de_consultas(request):
    consultas = AgendamentoConsulta.objects.all().order_by('-data')
    status_opcoes = AgendamentoConsulta.Status_consulta
    return render(request, 'lista_de_consultas.html', {
        'consultas': consultas,
        'status_opcoes': status_opcoes,
    })

@login_required(login_url='login')
def consulta_eventos(request):
    eventos = []
    for c in AgendamentoConsulta.objects.all():
        eventos.append({
             "id":  c.id,
            "title": f"{c.paciente.paciente} - {c.medico.medico}",
            "start": c.data.strftime("%Y-%m-%dT%H:%M:%S"),
            "color": "#" + "".join([random.choice("0123456789ABCDEF") for _ in range(6)]),
        })
        print(eventos)
    return JsonResponse(eventos, safe=False)

@login_required(login_url='login')
def consulta_eventos_medicos(request):
    medicos = request.GET.get("medico")
    print(medicos)
    eventos = []
    
    for c in AgendamentoConsulta.objects.filter(medico__id=medicos):
        eventos.append({
            "id": c.id,
            "title": f"{c.paciente.paciente} - {c.medico.medico}",
            "start": c.data.strftime("%Y-%m-%dT%H:%M:%S"),
            "color": "gray"
        })
        print(eventos)
    return JsonResponse(eventos, safe=False)

@login_required(login_url='login')
def excluir_cliente(request, pk):
    cliente = get_object_or_404(Cliente, pk=pk)
    if request.method == 'POST':
        cliente.delete()
        messages.success(request, 'Paciente excluído com sucesso!')
    return redirect('lista_de_clientes')

@login_required(login_url='login')
def excluir_medico(request, pk):
    medico = get_object_or_404(Medico, pk=pk)
    if request.method == 'POST':
        medico.delete()
        messages.success(request, 'Médico excluído com sucesso!')
    return redirect('lista_de_medicos')

@login_required(login_url='login')
def excluir_consulta(request, pk):
    consulta = get_object_or_404(AgendamentoConsulta, pk=pk)
    if request.method == 'POST':
        consulta.delete()
        messages.success(request, 'Consulta excluída com sucesso!')
    return redirect('lista_de_consultas')

@login_required(login_url='login')
def alterar_status_consulta(request, pk):
    consulta = get_object_or_404(AgendamentoConsulta, pk=pk)
    if request.method == 'POST':
        novo_status = request.POST.get('status_consulta')
        if novo_status in ['A', 'O', 'R']:  
            consulta.status_consulta = novo_status
            consulta.save()
            messages.success(request, 'Status atualizado com sucesso!')
    return redirect('lista_de_consultas')